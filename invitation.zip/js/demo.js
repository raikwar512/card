function place() {
    let div = document.querySelector(".madhu");
    div.innerText = " Madhuvan Garden Khajuraho Road Bamitha Dist. Chhatarpur (M.P.)";
    let btn = document.querySelector(".btn")
    btn.innerHTML("");
}